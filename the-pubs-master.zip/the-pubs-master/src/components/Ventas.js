// components/Ventas.js
import React from 'react';

function Ventas() {
  return (
    <div class="card">
    <div class="card-title">Ventas</div>
    <div>S/113.00</div>
</div>
  );
}

export default Ventas;
