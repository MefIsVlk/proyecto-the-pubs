// components/Principal.js
import React from 'react';

function Compras() {
  return (
    <div class="card">
                <div class="card-title">Compras</div>
                <div>S/113.00</div>
    </div>
  );
}

export default Compras;
