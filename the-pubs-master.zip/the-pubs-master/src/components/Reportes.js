// components/Principal.js
import React from 'react';

function Reportes() {
  return (
    <div class="card">
                <div class="card-title">Reportes</div>
                <div>S/113.00</div>
    </div>
  );
}

export default Reportes;
