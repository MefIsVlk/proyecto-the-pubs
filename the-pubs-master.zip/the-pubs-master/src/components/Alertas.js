// components/Principal.js
import React from 'react';

function Alertas() {
  return (
    <div class="card">
                <div class="card-title">Alertas</div>
                <div>S/113.00</div>
    </div>
  );
}

export default Alertas;
