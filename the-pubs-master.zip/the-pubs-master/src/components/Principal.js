// components/Principal.js
import React from 'react';

function Principal() {
  return (
    <div class="card">
                <div class="card-title">Principal</div>
                <div>S/113.00</div>
    </div>
  );
}

export default Principal;
