// components/Sidebar.js
import React from 'react';
import { Link } from 'react-router-dom';

function Sidebar() {
  return (
    <div className="sidebar">
      <ul>
        <li><Link to="/">Principal</Link></li>
        <li><Link to="/ventas">Ventas</Link></li>
        <li><Link to="/TerminalPost">TerminalPost</Link></li>
        <li><Link to="/Reportes">Reportes</Link></li>
        <li><Link to="/Pedidos">Pedidos</Link></li>
        <li><Link to="/Inventario">Inventario</Link></li>
        <li><Link to="/Compras">Compras</Link></li>
        <li><Link to="/Alertas">Alertas</Link></li>
        <li><Link to="/Administracaja">Administracaja</Link></li>
      </ul>
    </div>
  );
}

export default Sidebar;
