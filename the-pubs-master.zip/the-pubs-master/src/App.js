import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Principal from './components/Principal'; // Si moviste los archivos a components
import Ventas from './components/Ventas'; 
import TerminalPost from './components/TerminalPost';
import Reportes from './components/Reportes';
import Pedidos from './components/Pedidos';
import Inventario from './components/Inventario';
import Compras from './components/Compras';
import Alertas from './components/Alertas'; 
import Administracaja from './components/Administracaja';       // Si moviste los archivos a components
import './App.css';

function App() {
  return (
    <Router>
      <div className="app">
        <Sidebar />
        <div className="content">
          <Routes>
            <Route path="/" element={<Principal />} />
            <Route path="/ventas" element={<Ventas />} />
            <Route path="/TerminalPost" element={<TerminalPost />} />
            <Route path="/Reportes" element={<Reportes />} />
            <Route path="/Pedidos" element={<Pedidos />} />
            <Route path="/Inventario" element={<Inventario />} />
            <Route path="/Compras" element={<Compras />} />
            <Route path="/Alertas" element={<Alertas />} />
            <Route path="/Administracaja" element={<Administracaja />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
